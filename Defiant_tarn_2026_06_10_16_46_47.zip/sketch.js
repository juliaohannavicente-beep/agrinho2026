function setup() {
  createCanvas(900, 600);
}

function draw() {
  background(135, 206, 235); // céu

  // Sol
  fill(255, 204, 0);
  noStroke();
  circle(750, 100, 100);

  // Chão
  fill(80, 180, 80);
  rect(0, 350, width, 250);

  // Plantações
  for (let x = 50; x < width; x += 50) {
    drawPlant(x, 420);
    drawPlant(x, 500);
  }

  // Trator
  drawTractor(400, 320);

  // Nuvens
  drawCloud(150, 100);
  drawCloud(300, 80);
  drawCloud(500, 120);

  // Título
  fill(0);
  textAlign(CENTER);
  textSize(36);
  textStyle(BOLD);
  text("AGRO FORTE", width / 2, 50);

  // Slogan
  textSize(20);
  text("Tecnologia, Produção e Sustentabilidade", width / 2, 85);
}

function drawPlant(x, y) {
  // Caule
  stroke(0, 120, 0);
  strokeWeight(3);
  line(x, y, x, y - 40);

  // Folhas
  fill(0, 180, 0);
  noStroke();
  ellipse(x - 8, y - 25, 15, 8);
  ellipse(x + 8, y - 15, 15, 8);
  ellipse(x - 8, y - 5, 15, 8);
}

function drawTractor(x, y) {
  // Corpo
  fill(220, 0, 0);
  rect(x, y, 120, 50);

  // Cabine
  fill(180);
  rect(x + 70, y - 40, 40, 40);

  // Rodas
  fill(30);
  circle(x + 25, y + 55, 50);
  circle(x + 100, y + 55, 70);

  fill(120);
  circle(x + 25, y + 55, 25);
  circle(x + 100, y + 55, 35);
}

function drawCloud(x, y) {
  fill(255);
  noStroke();
  ellipse(x, y, 50, 50);
  ellipse(x + 30, y, 60, 60);
  ellipse(x + 60, y, 50, 50);
}





